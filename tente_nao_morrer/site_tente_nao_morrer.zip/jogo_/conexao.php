<?php 
$database = "tente_nao_morrer";
$username = "root";
$hostname = "localhost";
$password = "1234";
$conexao   = mysqli_connect($hostname,$username,$password,$database);

?>